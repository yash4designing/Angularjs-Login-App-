<?php 
require_once 'config.php' ; 
if (isset($_POST['value']))
{ 
global $dbc;
$dbc= mysql_query("SELECT id,username,password from users WHERE username='".$_POST['username']."' && password='". md5($_POST['password'])."'");
  
  $dbc->execute();
  $row = $dbc->rowCount();
  if ($row > 0){
  echo 'correct';
  } else{
  echo 'wrong';
  }
}
  ?>
